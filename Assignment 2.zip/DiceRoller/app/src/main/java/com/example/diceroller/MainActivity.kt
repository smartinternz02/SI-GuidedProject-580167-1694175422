package com.example.diceroller

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rollButton: Button = findViewById(R.id.rollButton)
        rollButton.setOnClickListener {
            val numberRolled: Int = (1..6).random() //Generating a random number between 1 to 6
            val dice: ImageView = findViewById(R.id.diceImage)
            val diceImage = when (numberRolled) {
                1 -> R.drawable.dice_1
                2 -> R.drawable.dice_2
                3 -> R.drawable.dice_3
                4 -> R.drawable.dice_4
                5 -> R.drawable.dice_5
                else -> R.drawable.dice_6
            }
            dice.setImageResource(diceImage)
            findViewById<TextView>(R.id.numberRolled).text = "Number rolled: $numberRolled" //Displaying the number rolled
            dice.contentDescription = numberRolled.toString()
        }
    }
}

//By Himay Mehta(21BCE10788)